for EXAMPLE in *.py
  do python $EXAMPLE
done
